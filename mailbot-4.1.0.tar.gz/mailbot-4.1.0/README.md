<img src="https://res.cloudinary.com/rakinar2/image/upload/v1651761587/MailBot-presentation2_ym78uk.png" width="100%">

# Mailbot

[![Build](https://github.com/virtual-designer/mailbot/actions/workflows/build.yml/badge.svg)](https://github.com/virtual-designer/mailbot/actions/workflows/build.yml)
![GitHub package.json version (subfolder of monorepo)](https://img.shields.io/github/package-json/v/virtual-designer/mailbot?label=Version)
![](https://img.shields.io/github/languages/top/virtual-designer/mailbot?color=yellow&label=JavaScript)
![GitHub](https://img.shields.io/github/license/virtual-designer/mailbot?color=%23007bff&label=License)

A Discord bot for contacting server staff. 
This bot was specially made for [The Everything Server](https://discord.gg/x7DHfyh4NS) Discord server.

## Setup
Before running the bot make sure that you've copied `config/config-sample.json` to `config/config.json`!
<!-- When running the bot for the first time, run `-setup` in the server where the bot is in. -->

### Support
Please email at rakinar2@onesoftnet.eu.org.
