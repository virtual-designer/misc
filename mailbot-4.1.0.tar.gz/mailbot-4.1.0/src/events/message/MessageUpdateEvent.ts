/**
* This file is part of MailBot.
* 
* Copyright (C) 2021-2022 OSN Inc.
*
* MailBot is free software; you can redistribute it and/or modify it
* under the terms of the GNU Affero General Public License as published by 
* the Free Software Foundation, either version 3 of the License, or
* (at your option) any later version.
* 
* MailBot is distributed in the hope that it will be useful, but
* WITHOUT ANY WARRANTY; without even the implied warranty of 
* MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the 
* GNU Affero General Public License for more details.
*
* You should have received a copy of the GNU Affero General Public License 
* along with MailBot. If not, see <https://www.gnu.org/licenses/>.
*/

import BaseEvent from '../../utils/structures/BaseEvent';
import { ChannelType, Message } from 'discord.js';
import DiscordClient from '../../client/Client';

export default class MessageUpdateEvent extends BaseEvent {
    constructor() {
        super('messageUpdate');
    }

    async run(client: DiscordClient, oldMessage: Message, newMessage: Message) {
        if (newMessage.author.bot) 
            return;

        if (newMessage.channel.type === ChannelType.DM || !newMessage.guild) {
            client.emit('dmUpdate', oldMessage, newMessage);
            return;
        }

        const replyCommands = [...client.commands.get('reply')!.getAllNames(), ...client.commands.get('update')!.getAllNames()];

        if (replyCommands.some(cmd => newMessage.content.startsWith(`${client.config.prefix}${cmd}`))) {
            console.log("Update staff message");
        }
    }
}